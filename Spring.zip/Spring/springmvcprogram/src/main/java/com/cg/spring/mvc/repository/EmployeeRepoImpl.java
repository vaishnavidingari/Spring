package com.cg.spring.mvc.repository;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.cg.spring.mvc.bean.Employee;



@Component
public class EmployeeRepoImpl implements IEmployeeRepo  {

	List<Employee>list=new ArrayList();
	public List<Employee> getAllEmployes() {
		
		return list;
	}
	public void add(Employee e) {
		Employee e1=new Employee();
		e1.setId(list.size()+1);
		e1.setName("vineeth");
		e1.setSalary(18000);
		e1.setMailid("vin@gmail.com");
	    list.add(e1);
	    Employee e2=new Employee();
		e2.setId(list.size()+1);
		e2.setName("ajay");
		e2.setSalary(10000);
		e2.setMailid("aj@gmail.com");
		list.add(e2);
		e.setId(list.size()+1);
		list.add(e);
		
	}
	public Employee searchById(int id) {
		for(Employee e:list) {
			if(e.getId()==id) {
				return e;
			}
		}
		return null;
	}
	
	public Employee update(int id, double salary) {
		for(Employee e:list) {
			if(e.getId()==id) {
				e.setSalary(salary);
				return e;
			}
		}
		return null;
	}
	
	public void delete(int id) {
		for(Employee e:list) {
			if(e.getId()==id) {
				list.remove(e);
			}
		}
	}
	
	
	
}

