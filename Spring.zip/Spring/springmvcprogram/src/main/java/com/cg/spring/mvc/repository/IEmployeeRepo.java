package com.cg.spring.mvc.repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.cg.spring.mvc.bean.Employee;



@Repository
public interface IEmployeeRepo {
	List<Employee>getAllEmployes();
	void add(Employee e);
	Employee searchById(int id);
	Employee update(int id,double salary);
	void delete(int id);

}
