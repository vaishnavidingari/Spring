package com.cg.spring.mvc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.spring.mvc.bean.Employee;
import com.cg.spring.mvc.repository.IEmployeeRepo;

@Component
public class EmployeeServiceImpl implements IEmployeeService{

	@Autowired
	IEmployeeRepo repo;
	public List<Employee> getAllEmployes() {
		return repo.getAllEmployes();
	
	}

	public void add(Employee e) {
		repo.add(e);
		
	}

	public Employee searchById(int id) {
		
		return repo.searchById(id);
	}

	public Employee update(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	public void delete(int id) {
		repo.delete(id);
		
	}

	public Employee update(int id, int salary) {
		
		return repo.update(id, salary);
	}

}
