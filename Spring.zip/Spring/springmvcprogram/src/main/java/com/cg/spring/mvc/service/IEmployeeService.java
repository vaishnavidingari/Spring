package com.cg.spring.mvc.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.cg.spring.mvc.bean.Employee;


@Service
public interface IEmployeeService {
	List<Employee>getAllEmployes();
	void add(Employee e);
	Employee searchById(int id);
	Employee update(int id, int salary);
	void delete(int id);

}
