package com.cg.spring.mvc.repository;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.cg.spring.mvc.beans.Product;
@Component
public class ProductRepoImpl implements IProductRepo
{
	List<Product> list= new ArrayList();
	public List<Product> getAllProducts() {
		return list;
	
	}
	public void add(Product p) {
		
		p.setId(list.size()+1);
		list.add(p);
	}
	public Product searchById(int id) {
	for(Product p:list) {
		if(p.getId()==id) {
			return p;
		}
	}
		return null;
	}
}
