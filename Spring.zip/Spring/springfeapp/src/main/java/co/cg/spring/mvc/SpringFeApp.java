package co.cg.spring.mvc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages="com.cg.spring.mvc")
public class SpringFeApp {

	public static void main(String[] args) {
	SpringApplication.run(SpringFeApp.class, args);
	}

}
