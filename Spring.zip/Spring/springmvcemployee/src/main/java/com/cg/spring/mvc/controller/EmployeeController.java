package com.cg.spring.mvc.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.spring.mvc.beans.Employee;

import com.cg.spring.mvc.service.IEmployeeService;


@Controller
public class EmployeeController {
	@Autowired
	IEmployeeService service;
	@RequestMapping(value="/getall",method=RequestMethod.GET)
	public ModelAndView getAllEmployeeDetails() {
		ModelAndView mv= new ModelAndView("showallemp");
		mv.addObject("employee",service.getAllEmployeeDetails());
		return mv;
		
	}
	@RequestMapping(value="/addp", method=RequestMethod.GET)
	public ModelAndView addemployee() {
		ModelAndView mv= new ModelAndView("addemp");
		mv.addObject("command",new Employee());
		return mv;
	}
	@RequestMapping(value="/addemployee",method=RequestMethod.POST)
	public String add(Employee e) {
		service.add(e);
		return"redirect:/getall";
	}
	@RequestMapping(value="/upd", method=RequestMethod.GET)
    public ModelAndView updateEmployee(@RequestParam("id") int id,@RequestParam("name") String name,@RequestParam("mailid") String mailid) {
    	
     	ModelAndView mv=new ModelAndView("update");
 		mv.addObject("id",new Integer(id));
 		mv.addObject("name",new String(name));
 		mv.addObject("mailid",new String(mailid));
 		mv.addObject("command",new Employee());
 		return mv;
     }
    @RequestMapping(value="/update", method=RequestMethod.POST)

    public String addi1(@RequestParam("id") int id,@RequestParam("salary") int salary) {
    	service.update(id,salary);
		return "redirect:/getall";
    }
    
    
    @RequestMapping(value="/delete", method=RequestMethod.GET)
    public String delete(@RequestParam("id") int id) {
    	service.delete(id);
		return "redirect:/getall";
    }
}
