package com.cg.spring.mvc.repository;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.cg.spring.mvc.beans.Employee;
@Component
public class EmployeeRepoImpl implements IEmployeeRepo{
	List<Employee> list= new ArrayList();

	public List<Employee> getAllEmployeeDetails() {
		return list;
	}

	public void add(Employee e) {
			Employee e1=new Employee();
			e1.setId(list.size()+1);
			e1.setName("vineeth");
			e1.setSalary(18000);
			e1.setEmail("vin@gmail.com");
		    list.add(e1);
		    Employee e2=new Employee();
		    e2.setId(list.size()+1);
			e2.setName("ajay");
			e2.setSalary(10000);
			e2.setEmail("aj@gmail.com");
			list.add(e2);
			e.setId(list.size()+1);
			list.add(e);
			
		}

	public void delete(int id) {
		// TODO Auto-generated method stub
		for(Employee e:list) {
			if(e.getId()==id) {
				list.remove(e);
			}
		}
		
	}

	public Employee update(int id, int salary) {
		// TODO Auto-generated method stub
		for(Employee e:list) {
			if(e.getId()==id) {
				e.setSalary(salary);
				return e;
			}
		}
		return null;
	}

	public Employee update(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	
	

}
